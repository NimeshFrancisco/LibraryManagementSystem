package datamanagement;
public class StudentUnitRecordMap extends java.util.HashMap<String, IStudentUnitRecord>{}
