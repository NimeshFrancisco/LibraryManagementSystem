//unit maping 

package datamanagement;

public class UnitMap extends java.util.HashMap<String, IUnit> {
}
