package library.interfaces.hardware;

public interface IScannerListener {
	
	public void bookScanned(int barcode);

}
