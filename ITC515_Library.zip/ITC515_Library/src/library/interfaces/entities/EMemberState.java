package library.interfaces.entities;

public enum EMemberState { 
	
	BORROWING_ALLOWED, BORROWING_DISALLOWED 

}	
