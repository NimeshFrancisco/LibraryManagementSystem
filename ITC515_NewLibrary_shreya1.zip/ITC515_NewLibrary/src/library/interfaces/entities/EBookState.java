package library.interfaces.entities;

public enum EBookState {
	AVAILABLE, ON_LOAN, LOST, DAMAGED, DISPOSED 

}
